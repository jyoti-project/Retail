from app import app
from models import db, User, Product, Order, OrderItem, UserBehavior
from werkzeug.security import generate_password_hash
import random

def setup_sample_data():
    """Setup sample data for the RetailFlow AI application"""
    
    with app.app_context():
        # Clear existing data
        db.drop_all()
        db.create_all()
        
        # Create admin user
        admin = User(
            username='admin',
            email='admin@retailflow.com',
            password_hash=generate_password_hash('admin123'),
            is_admin=True
        )
        db.session.add(admin)
        
        # Create sample users
        users = [
            User(username='john_doe', email='john@example.com', password_hash=generate_password_hash('password123')),
            User(username='jane_smith', email='jane@example.com', password_hash=generate_password_hash('password123')),
            User(username='mike_wilson', email='mike@example.com', password_hash=generate_password_hash('password123')),
        ]
        
        for user in users:
            db.session.add(user)
        
        # Create sample products
        products = [
            # Clothing
            Product(name='Classic White T-Shirt', description='Comfortable cotton t-shirt perfect for everyday wear', 
                   price=19.99, category='clothing', stock_quantity=50, 
                   image_url='https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300&h=300&fit=crop'),
            
            Product(name='Denim Jeans', description='Premium quality denim jeans with perfect fit', 
                   price=79.99, category='clothing', stock_quantity=30, 
                   image_url='https://images.unsplash.com/photo-1542272604-787c3835535d?w=300&h=300&fit=crop'),
            
            Product(name='Summer Dress', description='Elegant summer dress for special occasions', 
                   price=89.99, category='clothing', stock_quantity=25, 
                   image_url='https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=300&h=300&fit=crop'),
            
            Product(name='Leather Jacket', description='Stylish leather jacket for a bold look', 
                   price=199.99, category='clothing', stock_quantity=15, 
                   image_url='https://images.unsplash.com/photo-1551028719-00167b16eac5?w=300&h=300&fit=crop'),
            
            # Accessories
            Product(name='Designer Sunglasses', description='UV protection sunglasses with modern design', 
                   price=129.99, category='accessories', stock_quantity=40, 
                   image_url='https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=300&h=300&fit=crop'),
            
            Product(name='Leather Handbag', description='Premium leather handbag for everyday use', 
                   price=159.99, category='accessories', stock_quantity=20, 
                   image_url='https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=300&h=300&fit=crop'),
            
            Product(name='Smart Watch', description='Feature-rich smartwatch with health tracking', 
                   price=299.99, category='accessories', stock_quantity=35, 
                   image_url='https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300&h=300&fit=crop'),
            
            # Shoes
            Product(name='Running Sneakers', description='Comfortable running shoes for active lifestyle', 
                   price=119.99, category='shoes', stock_quantity=45, 
                   image_url='https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=300&h=300&fit=crop'),
            
            Product(name='Formal Dress Shoes', description='Elegant dress shoes for formal occasions', 
                   price=149.99, category='shoes', stock_quantity=25, 
                   image_url='https://images.unsplash.com/photo-1549298916-b41d501d3772?w=300&h=300&fit=crop'),
            
            Product(name='Casual Boots', description='Versatile boots perfect for any season', 
                   price=89.99, category='shoes', stock_quantity=30, 
                   image_url='https://images.unsplash.com/photo-1608256246200-53e8b47b2dc1?w=300&h=300&fit=crop'),
            
            # Electronics
            Product(name='Wireless Headphones', description='High-quality wireless headphones with noise cancellation', 
                   price=199.99, category='electronics', stock_quantity=40, 
                   image_url='https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=300&fit=crop'),
            
            Product(name='Smartphone Case', description='Protective case for your smartphone', 
                   price=29.99, category='electronics', stock_quantity=100, 
                   image_url='https://images.unsplash.com/photo-1601593346740-925612772716?w=300&h=300&fit=crop'),
        ]
        
        for product in products:
            db.session.add(product)
        
        db.session.commit()
        
        # Create sample orders and user behavior
        for i, user in enumerate(users):
            # Create some orders
            for j in range(random.randint(1, 3)):
                order = Order(user_id=user.id, status='completed', total_amount=0)
                db.session.add(order)
                db.session.flush()
                
                # Add items to order
                order_total = 0
                for k in range(random.randint(1, 4)):
                    product = random.choice(products)
                    quantity = random.randint(1, 3)
                    
                    order_item = OrderItem(
                        order_id=order.id,
                        product_id=product.id,
                        quantity=quantity,
                        price=product.price
                    )
                    db.session.add(order_item)
                    order_total += product.price * quantity
                
                order.total_amount = order_total
            
            # Create user behavior data
            for j in range(random.randint(10, 30)):
                product = random.choice(products)
                action = random.choice(['view', 'view', 'view', 'add_to_cart'])  # More views than cart adds
                
                behavior = UserBehavior(
                    user_id=user.id,
                    product_id=product.id,
                    action=action
                )
                db.session.add(behavior)
        
        db.session.commit()
        print("Sample data created successfully!")
        print("\nLogin credentials:")
        print("Admin: admin@retailflow.com / admin123")
        print("User: john@example.com / password123")
        print("User: jane@example.com / password123")
        print("User: mike@example.com / password123")

if __name__ == '__main__':
    setup_sample_data()