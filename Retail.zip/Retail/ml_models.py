from datetime import datetime, timedelta
import json
import random
from models import User, Product, Order, OrderItem, UserBehavior

class RecommendationEngine:
    def __init__(self):
        pass
        
    def get_recommendations(self, user_id, limit=5):
        """Get product recommendations based on user behavior"""
        try:
            # Get user's viewed/purchased products
            user_behaviors = UserBehavior.query.filter_by(user_id=user_id).all()
            if not user_behaviors:
                return self._get_popular_products(limit)
            
            # Get categories user is interested in
            viewed_products = [b.product_id for b in user_behaviors]
            products = Product.query.filter(Product.id.in_(viewed_products)).all()
            
            if not products:
                return self._get_popular_products(limit)
            
            # Find similar products based on category and description
            categories = [p.category for p in products]
            similar_products = Product.query.filter(
                Product.category.in_(categories),
                ~Product.id.in_(viewed_products),
                Product.is_active == True
            ).limit(limit).all()
            
            return [{'id': p.id, 'name': p.name, 'price': p.price, 'image_url': p.image_url} 
                   for p in similar_products]
        except:
            return self._get_popular_products(limit)
    
    def _get_popular_products(self, limit=5):
        """Fallback to popular products"""
        products = Product.query.filter_by(is_active=True).limit(limit).all()
        return [{'id': p.id, 'name': p.name, 'price': p.price, 'image_url': p.image_url} 
               for p in products]

class DemandForecaster:
    def __init__(self):
        pass
        
    def generate_forecast(self):
        """Generate demand forecast for next 30 days"""
        try:
            # Get historical sales data
            orders = Order.query.filter(
                Order.created_at >= datetime.utcnow() - timedelta(days=90)
            ).all()
            
            if len(orders) < 10:
                return self._generate_mock_forecast()
            
            # Prepare data
            daily_sales = {}
            for order in orders:
                date_key = order.created_at.date()
                if date_key not in daily_sales:
                    daily_sales[date_key] = 0
                daily_sales[date_key] += order.total_amount
            
            # Simple trend analysis
            dates = sorted(daily_sales.keys())
            sales = [daily_sales[date] for date in dates]
            
            if len(sales) < 7:
                return self._generate_mock_forecast()
            
            # Calculate trend
            recent_avg = sum(sales[-7:]) / 7
            overall_avg = sum(sales) / len(sales)
            trend = (recent_avg - overall_avg) / overall_avg if overall_avg > 0 else 0
            
            # Generate forecast
            forecast = []
            base_value = recent_avg
            
            for i in range(30):
                # Add some randomness and trend
                daily_forecast = base_value * (1 + trend * 0.1) * (0.8 + random.random() * 0.4)
                forecast.append({
                    'date': (datetime.utcnow() + timedelta(days=i+1)).strftime('%Y-%m-%d'),
                    'predicted_sales': round(daily_forecast, 2)
                })
            
            return forecast
        except:
            return self._generate_mock_forecast()
    
    def _generate_mock_forecast(self):
        """Generate mock forecast data"""
        forecast = []
        base_value = 1000
        
        for i in range(30):
            daily_forecast = base_value * (0.8 + random.random() * 0.4)
            forecast.append({
                'date': (datetime.utcnow() + timedelta(days=i+1)).strftime('%Y-%m-%d'),
                'predicted_sales': round(daily_forecast, 2)
            })
        
        return forecast

class VirtualTryOn:
    def __init__(self):
        pass
    
    def try_on(self, user_image, product_id):
        """Simulate virtual try-on (simplified version)"""
        try:
            product = Product.query.get(product_id)
            if not product:
                return {'error': 'Product not found'}
            
            # In a real implementation, this would use advanced AR/ML
            # For demo purposes, we'll return a mock result
            return {
                'success': True,
                'message': f'Virtual try-on simulation for {product.name}',
                'product_name': product.name,
                'fit_score': random.randint(70, 95),
                'recommendations': [
                    'This item fits well with your body type',
                    'Consider sizing up for a looser fit',
                    'Great color match for your skin tone'
                ]
            }
        except Exception as e:
            return {'error': f'Try-on failed: {str(e)}'}
    
    def analyze_fit(self, image_data, product_data):
        """Analyze how well a product fits"""
        # Simplified fit analysis
        return {
            'fit_percentage': random.randint(75, 95),
            'size_recommendation': 'Medium',
            'style_match': random.randint(80, 100)
        }