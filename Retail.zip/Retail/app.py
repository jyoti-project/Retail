from flask import Flask, render_template, request, jsonify, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta
import os
import json
from models import db, User, Product, Order, OrderItem, UserBehavior, ChatMessage
from ml_models import RecommendationEngine, DemandForecaster, VirtualTryOn
from chatbot import RetailChatbot

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///retailflow.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/images/products'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Initialize ML components
recommendation_engine = RecommendationEngine()
demand_forecaster = DemandForecaster()
virtual_tryon = VirtualTryOn()
chatbot = RetailChatbot()

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Routes
@app.route('/')
def index():
    products = Product.query.filter_by(is_active=True).limit(12).all()
    if current_user.is_authenticated:
        recommendations = recommendation_engine.get_recommendations(current_user.id)
    else:
        recommendations = []
    return render_template('index.html', products=products, recommendations=recommendations)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(url_for('admin_dashboard' if user.is_admin else 'index'))
        return render_template('login.html', error='Invalid credentials')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        if User.query.filter_by(email=email).first():
            return render_template('register.html', error='Email already exists')
        
        user = User(
            username=username,
            email=email,
            password_hash=generate_password_hash(password)
        )
        db.session.add(user)
        db.session.commit()
        login_user(user)
        return redirect(url_for('index'))
    
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/admin')
@login_required
def admin_dashboard():
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    total_products = Product.query.count()
    total_orders = Order.query.count()
    total_users = User.query.count()
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(10).all()
    
    # Demand forecasting
    forecast_data = demand_forecaster.generate_forecast()
    
    return render_template('admin/dashboard.html', 
                         total_products=total_products,
                         total_orders=total_orders,
                         total_users=total_users,
                         recent_orders=recent_orders,
                         forecast_data=forecast_data)

@app.route('/admin/products')
@login_required
def admin_products():
    if not current_user.is_admin:
        return redirect(url_for('index'))
    products = Product.query.all()
    return render_template('admin/products.html', products=products)

@app.route('/admin/add_product', methods=['GET', 'POST'])
@login_required
def add_product():
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        image_url = request.form['image_url']
        
        # Handle file upload
        if 'image_file' in request.files:
            file = request.files['image_file']
            if file and file.filename:
                filename = secure_filename(file.filename)
                if not os.path.exists(app.config['UPLOAD_FOLDER']):
                    os.makedirs(app.config['UPLOAD_FOLDER'])
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)
                image_url = f'/static/images/products/{filename}'
        
        product = Product(
            name=request.form['name'],
            description=request.form['description'],
            price=float(request.form['price']),
            category=request.form['category'],
            stock_quantity=int(request.form['stock_quantity']),
            image_url=image_url
        )
        db.session.add(product)
        db.session.commit()
        return redirect(url_for('admin_products'))
    
    return render_template('admin/add_product.html')

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    product = Product.query.get_or_404(product_id)
    
    # Track user behavior
    if current_user.is_authenticated:
        behavior = UserBehavior(
            user_id=current_user.id,
            product_id=product_id,
            action='view'
        )
        db.session.add(behavior)
        db.session.commit()
    
    return render_template('product_detail.html', product=product)

@app.route('/cart')
@login_required
def cart():
    cart_items = session.get('cart', [])
    products = []
    total = 0
    
    for item in cart_items:
        product = Product.query.get(item['product_id'])
        if product:
            products.append({
                'product': product,
                'quantity': item['quantity']
            })
            total += product.price * item['quantity']
    
    return render_template('cart.html', products=products, total=total)

@app.route('/add_to_cart', methods=['POST'])
@login_required
def add_to_cart():
    product_id = int(request.form['product_id'])
    quantity = int(request.form.get('quantity', 1))
    
    cart = session.get('cart', [])
    
    # Check if product already in cart
    for item in cart:
        if item['product_id'] == product_id:
            item['quantity'] += quantity
            break
    else:
        cart.append({'product_id': product_id, 'quantity': quantity})
    
    session['cart'] = cart
    
    # Track behavior
    behavior = UserBehavior(
        user_id=current_user.id,
        product_id=product_id,
        action='add_to_cart'
    )
    db.session.add(behavior)
    db.session.commit()
    
    return redirect(url_for('cart'))

@app.route('/checkout', methods=['GET', 'POST'])
@login_required
def checkout():
    if request.method == 'POST':
        cart_items = session.get('cart', [])
        if not cart_items:
            return redirect(url_for('cart'))
        
        # Create order
        order = Order(user_id=current_user.id, status='pending')
        db.session.add(order)
        db.session.flush()
        
        total = 0
        for item in cart_items:
            product = Product.query.get(item['product_id'])
            if product and product.stock_quantity >= item['quantity']:
                order_item = OrderItem(
                    order_id=order.id,
                    product_id=product.id,
                    quantity=item['quantity'],
                    price=product.price
                )
                db.session.add(order_item)
                
                # Update stock
                product.stock_quantity -= item['quantity']
                total += product.price * item['quantity']
        
        order.total_amount = total
        db.session.commit()
        
        # Clear cart
        session['cart'] = []
        
        return redirect(url_for('order_success', order_id=order.id))
    
    return render_template('checkout.html')

@app.route('/order_success/<int:order_id>')
@login_required
def order_success(order_id):
    order = Order.query.get_or_404(order_id)
    if order.user_id != current_user.id:
        return redirect(url_for('index'))
    return render_template('order_success.html', order=order)

@app.route('/virtual_tryon', methods=['POST'])
@login_required
def virtual_tryon_api():
    if 'image' not in request.files:
        return jsonify({'error': 'No image provided'}), 400
    
    image = request.files['image']
    product_id = request.form.get('product_id')
    
    if image and product_id:
        result = virtual_tryon.try_on(image, product_id)
        return jsonify(result)
    
    return jsonify({'error': 'Invalid request'}), 400

@app.route('/chat', methods=['POST'])
def chat():
    message = request.json.get('message')
    user_id = current_user.id if current_user.is_authenticated else None
    
    response = chatbot.get_response(message, user_id)
    
    # Save chat message
    if user_id:
        chat_msg = ChatMessage(
            user_id=user_id,
            message=message,
            response=response
        )
        db.session.add(chat_msg)
        db.session.commit()
    
    return jsonify({'response': response})

@app.route('/analytics')
@login_required
def analytics():
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    # User behavior analytics
    behaviors = UserBehavior.query.all()
    analytics_data = {
        'total_views': len([b for b in behaviors if b.action == 'view']),
        'total_cart_adds': len([b for b in behaviors if b.action == 'add_to_cart']),
        'popular_products': {}
    }
    
    # Popular products
    for behavior in behaviors:
        if behavior.product_id not in analytics_data['popular_products']:
            analytics_data['popular_products'][behavior.product_id] = 0
        analytics_data['popular_products'][behavior.product_id] += 1
    
    return render_template('admin/analytics.html', analytics=analytics_data)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        
        # Create admin user if not exists
        admin = User.query.filter_by(email='admin@retailflow.com').first()
        if not admin:
            admin = User(
                username='admin',
                email='admin@retailflow.com',
                password_hash=generate_password_hash('admin123'),
                is_admin=True
            )
            db.session.add(admin)
            db.session.commit()
    
    app.run(debug=True, port=5001)