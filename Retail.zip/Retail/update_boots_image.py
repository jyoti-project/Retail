from app import app
from models import db, Product

with app.app_context():
    # Find the casual boots product and update its image
    boots = Product.query.filter_by(name='Casual Boots').first()
    if boots:
        boots.image_url = 'https://images.unsplash.com/photo-1608256246200-53e8b47b2dc1?w=300&h=300&fit=crop'
        db.session.commit()
        print("Casual boots image updated successfully!")
    else:
        print("Casual boots product not found")