#!/usr/bin/env python3
"""
RetailFlow AI - E-Commerce Platform
Quick start script for the application
"""

import os
import sys
import subprocess

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required")
        print(f"Current version: {sys.version}")
        return False
    print(f"✅ Python version: {sys.version.split()[0]}")
    return True

def install_dependencies():
    """Install required dependencies"""
    print("📦 Installing dependencies...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ Dependencies installed successfully")
        return True
    except subprocess.CalledProcessError:
        print("❌ Failed to install dependencies")
        return False

def setup_database():
    """Setup database with sample data"""
    print("🗄️ Setting up database...")
    try:
        subprocess.check_call([sys.executable, "setup_data.py"])
        print("✅ Database setup completed")
        return True
    except subprocess.CalledProcessError:
        print("❌ Failed to setup database")
        return False

def run_application():
    """Run the Flask application"""
    print("🚀 Starting RetailFlow AI...")
    print("📱 Application will be available at: http://localhost:5000")
    print("👤 Admin login: admin@retailflow.com / admin123")
    print("👤 User login: john@example.com / password123")
    print("\n" + "="*50)
    
    try:
        subprocess.check_call([sys.executable, "app.py"])
    except KeyboardInterrupt:
        print("\n👋 Application stopped by user")
    except subprocess.CalledProcessError:
        print("❌ Failed to start application")

def main():
    """Main setup and run function"""
    print("🛍️ RetailFlow AI - E-Commerce Platform")
    print("="*50)
    
    # Check Python version
    if not check_python_version():
        return
    
    # Install dependencies
    if not install_dependencies():
        return
    
    # Setup database
    if not setup_database():
        return
    
    # Run application
    run_application()

if __name__ == "__main__":
    main()