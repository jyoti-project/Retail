import re
import json
from models import Product, Order, User

class RetailChatbot:
    def __init__(self):
        self.intents = {
            'greeting': ['hello', 'hi', 'hey', 'good morning', 'good afternoon'],
            'product_search': ['find', 'search', 'looking for', 'show me', 'product'],
            'order_status': ['order', 'status', 'track', 'tracking', 'delivery'],
            'price_inquiry': ['price', 'cost', 'how much', 'expensive'],
            'size_help': ['size', 'fit', 'sizing', 'measurements'],
            'return_policy': ['return', 'refund', 'exchange', 'policy'],
            'goodbye': ['bye', 'goodbye', 'see you', 'thanks', 'thank you']
        }
        
        self.responses = {
            'greeting': "Hello! Welcome to RetailFlow AI. How can I help you today?",
            'goodbye': "Thank you for shopping with RetailFlow AI! Have a great day!",
            'default': "I'm here to help! You can ask me about products, orders, prices, or sizing."
        }
    
    def get_response(self, message, user_id=None):
        """Generate chatbot response based on user message"""
        message_lower = message.lower()
        intent = self._classify_intent(message_lower)
        
        if intent == 'greeting':
            return self.responses['greeting']
        
        elif intent == 'product_search':
            return self._handle_product_search(message_lower)
        
        elif intent == 'order_status':
            return self._handle_order_status(user_id)
        
        elif intent == 'price_inquiry':
            return self._handle_price_inquiry(message_lower)
        
        elif intent == 'size_help':
            return self._handle_size_help()
        
        elif intent == 'return_policy':
            return self._handle_return_policy()
        
        elif intent == 'goodbye':
            return self.responses['goodbye']
        
        else:
            return self._handle_general_query(message_lower)
    
    def _classify_intent(self, message):
        """Classify user intent based on keywords"""
        for intent, keywords in self.intents.items():
            if any(keyword in message for keyword in keywords):
                return intent
        return 'general'
    
    def _handle_product_search(self, message):
        """Handle product search queries"""
        try:
            # Extract potential product keywords
            keywords = ['shirt', 'dress', 'shoes', 'jacket', 'pants', 'jeans', 'top']
            found_keywords = [kw for kw in keywords if kw in message]
            
            if found_keywords:
                # Search for products matching keywords
                products = Product.query.filter(
                    Product.name.contains(found_keywords[0]) | 
                    Product.description.contains(found_keywords[0]),
                    Product.is_active == True
                ).limit(3).all()
                
                if products:
                    response = f"I found these {found_keywords[0]} items for you:\n"
                    for product in products:
                        response += f"• {product.name} - ${product.price}\n"
                    response += "\nWould you like more details about any of these items?"
                    return response
            
            return "I can help you find products! Try searching for items like 'shirts', 'dresses', 'shoes', etc."
        
        except:
            return "I'm having trouble searching right now. Please try again later."
    
    def _handle_order_status(self, user_id):
        """Handle order status inquiries"""
        if not user_id:
            return "Please log in to check your order status."
        
        try:
            recent_orders = Order.query.filter_by(user_id=user_id).order_by(Order.created_at.desc()).limit(3).all()
            
            if not recent_orders:
                return "You don't have any recent orders. Start shopping to place your first order!"
            
            response = "Here are your recent orders:\n"
            for order in recent_orders:
                response += f"• Order #{order.id} - ${order.total_amount} - Status: {order.status.title()}\n"
            
            return response
        
        except:
            return "I'm having trouble accessing your orders right now. Please try again later."
    
    def _handle_price_inquiry(self, message):
        """Handle price-related questions"""
        return ("Our prices are competitive and we offer great value! "
                "You can see the price of any item on its product page. "
                "We also have regular sales and discounts - check our homepage for current offers!")
    
    def _handle_size_help(self):
        """Handle sizing questions"""
        return ("For sizing help:\n"
                "• Check our size guide on each product page\n"
                "• Use our virtual try-on feature for clothes\n"
                "• Read customer reviews for fit feedback\n"
                "• Contact us if you need specific measurements\n"
                "We offer easy exchanges if the size isn't perfect!")
    
    def _handle_return_policy(self):
        """Handle return policy questions"""
        return ("Our return policy:\n"
                "• 30-day return window\n"
                "• Items must be unused with tags\n"
                "• Free returns on orders over $50\n"
                "• Refunds processed within 5-7 business days\n"
                "• Easy online return process\n"
                "Need to return something? Contact our support team!")
    
    def _handle_general_query(self, message):
        """Handle general queries"""
        if 'help' in message:
            return ("I can help you with:\n"
                    "• Finding products\n"
                    "• Checking order status\n"
                    "• Pricing information\n"
                    "• Sizing guidance\n"
                    "• Return policy\n"
                    "What would you like to know?")
        
        elif any(word in message for word in ['shipping', 'delivery']):
            return ("Shipping information:\n"
                    "• Free shipping on orders over $50\n"
                    "• Standard delivery: 3-5 business days\n"
                    "• Express delivery: 1-2 business days\n"
                    "• Same-day delivery available in select cities")
        
        elif 'payment' in message:
            return ("We accept:\n"
                    "• Credit/Debit cards\n"
                    "• PayPal\n"
                    "• Apple Pay\n"
                    "• Google Pay\n"
                    "All payments are secure and encrypted!")
        
        else:
            return self.responses['default']