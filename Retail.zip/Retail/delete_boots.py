from app import app
from models import db, Product, UserBehavior, OrderItem

with app.app_context():
    # Find and delete the casual boots product
    boots = Product.query.filter_by(name='Casual Boots').first()
    if boots:
        # Delete related records first
        UserBehavior.query.filter_by(product_id=boots.id).delete()
        OrderItem.query.filter_by(product_id=boots.id).delete()
        
        # Delete the product
        db.session.delete(boots)
        db.session.commit()
        print("Casual Boots product deleted successfully!")
    else:
        print("Casual Boots product not found")